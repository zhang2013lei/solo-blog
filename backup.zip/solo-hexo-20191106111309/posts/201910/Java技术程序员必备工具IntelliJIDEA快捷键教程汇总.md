title: Java技术-程序员必备工具IntelliJ IDEA快捷键教程汇总
date: '2019-10-31 20:10:49'
updated: '2019-10-31 20:10:49'
tags: [idea]
permalink: /articles/2019/10/31/1572523849603.html
---
![请输入图片描述][1]

# Java开发工具IntelliJ IDEA快捷键使用文档 #
我先跟大家说说IntelliJ IDEA由来，一切都开始与2000年一次重构大型Java代码库的需求，不断在市场里面寻找，但是还是一无所获，所以我们自制了有史以来第一款Java代码自动重构工具，该工具演化为一款IDE，Intellij Idea，后来，把它移植到.NET，成为BeSharper，现在，我们已拥有20多种产品，覆盖所有主流语言和技术。我们甚至开发出了自己的编程语言！
### 一丶用户 ###
目前有三百多万开发人员开始使用这个工具，他们以java、c#、php、c++、python和JavaScript语言编辑。在这个工具的使用下，他们的构建、管理任务、审查代码。我们并非只重视经验丰富的开发人员，还有四十多万学生免费使用JeBrains提供的工具学习编程。我们善于和用户站在同一阵线，从提供技术支持到在会议上与大家交流讨论。
### 二丶团队 ###
我们的团队遍布世界各地，总共有超过600名团队成员，我们仍然保持创业精神和我们的初衷。这么多年来，很多人依然留着JeBrains。我们都是开发人员，目标一致，同甘共苦。我知道很多提高效率、编写高质量代码的方法，怎能不与他人分享这些方法呢？当我们面对问题时，经常回顾和思考。“能否更高效地解决这个问题”在JeBrains，当现有工具不够完美时，我们就创造自己的新工具。如果新工具好用，就有可能成为我们下一款产品。
### 三、动力 ###
我们现今的生活是如此依赖软件，而这要靠我们：开发人员，来产生重大影响。我们JeBrains人理解并共同承担这些责任。我么的工作是使软件开发更加高效和有趣。我们希望大家能专注于重要和挑战性的问题上，不受日常工作的琐事烦扰。我们是你的坚强后盾，你可以凭借自己编写的软件
## IntelliJ IDEA 主要优点 ##
• 允许开发人员在确保所有例程任务顺利进行的同时专注于开发。

• 让编写、调试、重构、测试和代码了解都变得轻松简单。

• 无缝处理异构式的 Java、Ruby、Groovy、Python 和 Scala 代码库。

• 自动维护代码质量。

• 跟踪和修复所有级别的错误——从语句到整个架构。

• 以最短的时间生成简洁、快速的执行代码。

• 适用于所有规模的项目——从个人级别项目到企业级别项目。

• 支持所有主要语言、技术和框架。

• 适用于流行的版本控制系统和持续集成服务器 TeamCity。

# 五大 Intellij IDEA快捷键 #

## 一丶自动代码  ##

Ctrl+Alt+O 优化导入的类和包

Ctrl+Alt+T 生成try catch 或者 Alt+enter

CTRL+ALT+T 把选中的代码放在 TRY{} IF{} ELSE{} 里

Ctrl + O 重写方法

Ctrl + I 实现方法

Ctr+shift+U 大小写转化

ALT+回车 导入包,自动修正

Ctrl+Shift+J，整合两行为一行

CTRL+空格 代码提示

CTRL+SHIFT+SPACE 自动补全代码

CTRL+ALT+L 格式化代码

CTRL+ALT+I 自动缩进

CTRL+ALT+O 优化导入的类和包

ALT+INSERT 生成代码(如GET,SET方法,构造函数等)

CTRL+E 最近更改的代码

CTRL+ALT+SPACE 类名或接口名提示

CTRL+P 方法参数提示

CTRL+Q，可以看到当前方法的声明

Shift+F6 重构-重命名 (包、类、方法、变量、甚至注释等)

Ctrl+Alt+V 提取变量

## 二丶查询快捷键 ##

ALT+7 靠左窗口显示当前文件的结构

Ctrl+F12 浮动显示当前文件的结构

ALT+F7 找到你的函数或者变量或者类的所有引用到的地方

CTRL+ALT+F7 找到你的函数或者变量或者类的所有引用到的地方

Ctrl+Shift+Alt+N 查找类中的方法或变量

双击SHIFT 在项目的所有目录查找文件

Ctrl+N 查找类

Ctrl+Shift+N 查找文件

CTRL+G 定位行

CTRL+F 在当前窗口查找文本

CTRL+SHIFT+F 在指定窗口查找文本

CTRL+R 在 当前窗口替换文本

CTRL+SHIFT+R 在指定窗口替换文本

ALT+SHIFT+C 查找修改的文件

CTRL+E 最近打开的文件

F3 向下查找关键字出现位置

SHIFT+F3 向上一个关键字出现位置

选中文本，按Alt+F3 ，高亮相同文本，F3逐个往下查找相同文本

F4 查找变量来源

CTRL+SHIFT+O 弹出显示查找内容

Ctrl+W 选中代码，连续按会有其他效果

F2 或Shift+F2 高亮错误或警告快速定位

Ctrl+Up/Down 光标跳转到第一行或最后一行下

Ctrl+B 快速打开光标处的类或方法

CTRL+ALT+B 找所有的子类

CTRL+SHIFT+B 找变量的类

Ctrl+Shift+上下键 上下移动代码

Ctrl+Alt+ left/right 返回至上次浏览的位置

Ctrl+H 显示类结构图

Ctrl+Q 显示注释文档

Alt+F1 查找代码所在位置

Alt+1 快速打开或隐藏工程面板

Alt+ left/right 切换代码视图

ALT+ ↑/↓ 在方法间快速移动定位

CTRL+ALT+ left/right 前后导航编辑过的地方

Ctrl＋Shift＋Backspace可以跳转到上次编辑的地

Alt+6 查找TODO

## 三丶其他快捷键 ##

CIRL+U 大小写切换

CTRL+Z 倒退

CTRL+SHIFT+Z 向前

CTRL+ALT+F12 资源管理器打开文件夹

ALT+F1 查找文件所在目录位置

SHIFT+ALT+INSERT 竖编辑模式

CTRL+W 选中代码，连续按会有其他效果

CTRL+B 快速打开光标处的类或方法

ALT+ ←/→ 切换代码视图

CTRL+ALT ←/→ 返回上次编辑的位置

ALT+ ↑/↓ 在方法间快速移动定位

SHIFT+F6 重构-重命名

CTRL+H 显示类结构图

CTRL+Q 显示注释文档

ALT+1 快速打开或隐藏工程面板

CTRL+SHIFT+UP/DOWN 代码向上/下移动。

CTRL+UP/DOWN 光标跳转到第一行或最后一行下

ESC 光标返回编辑框

SHIFT+ESC 光标返回编辑框,关闭无用的窗口

F1 帮助千万别按,很卡!

## 四丶调试快捷键 ##

alt+F8 debug时选中查看值

Alt+Shift+F9，选择 Debug

Alt+Shift+F10，选择 Run

Ctrl+Shift+F9，编译

Ctrl+Shift+F8，查看断点

F7，步入

Shift+F7，智能步入

Alt+Shift+F7，强制步入

F8，步过

Shift+F8，步出

Alt+Shift+F8，强制步过

Alt+F9，运行至光标处

Ctrl+Alt+F9，强制运行至光标处。

## 五丶重构 ##

Shift+F6 重构-重命名Ctrl+Shift+先上键Ctrl+X 删除行Ctrl+D 复制行Ctrl+/ 或 Ctrl+Shift+/ 注释（// 或者/*...*/ ）Ctrl+J 自动代码Ctrl+E 最近打开的文件

Ctrl+H 显示类结构图

Ctrl+Q 显示注释文档Alt+F1 查找代码所在位置Alt+1 快速打开或隐藏工程面板

Ctrl+Alt+ left/right 返回至上次浏览的位置Alt+ left/right 切换代码视图

Alt+ Up/Down 在方法间快速移动定位

F2 或Shift+F2 高亮错误或警告快速定位。

非常感谢大家的支持，我现在也是在工作， 也在学习新的知识，现在的技术发展的很快，很多新东西必须学习才能提高开发效率，但是java必须得学，基础的东西一定要打牢，其他的东西学起来就很快了，感谢大家的支持，有你们，很愉快！

最后，每一位读到这里的网友，感谢你们能耐心地看完。希望在成为一名更优秀的Java程序员的道路上，我们可以一起学习、一起进步。


  [1]: http://p3.pstatp.com/large/3b0700003d05c12328b2
