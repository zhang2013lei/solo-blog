title: 使用docker创建启动一个带延迟队列插件的rabbitmq
date: '2019-11-06 10:05:43'
updated: '2019-11-06 10:12:25'
tags: [rabbitmq]
permalink: /articles/2019/11/06/1573005943312.html
---
这篇没有什么太多的技术性只是做一个记录，也供大家参考

当然这里已经默认大家已经安装好docker

这里给出rabbitmq的镜像地址https://hub.docker.com/_/rabbitmq

我这里使用3.7-management版本

这里给出rabbitmq官网的插件地址http://www.rabbitmq.com/community-plugins.html

以及如何安装插件：

http://www.rabbitmq.com/installing-plugins.html

http://www.rabbitmq.com/plugins.html

因为这里需要启动的时候手动去安装rabbitmq_delayed_message_exchange延迟队列插件

所以我们这里需要自己写Dockerfile

首先我们从官网下载该插件然后解压，创建一个文件夹mydocker

把解压后的文件放入mydocker

进入该文件夹后vim Dockerfile

我这里贴出我自己的Dockerfile
```
FROM rabbitmq:3.7-management
COPY rabbitmq_delayed_message_exchange-20171201-3.7.x.ez /plugins
RUN rabbitmq-plugins enable --offline rabbitmq_mqtt rabbitmq_federation_management rabbitmq_stomp rabbitmq_delayed_message_exchange
```
很简单的一个Dockerfile文件

下面开始build
```
docker build -t myrabbitmq:3.7 .
```

docker-compose.yml
```
 rabbitmq:
  image: myrabbitmq:3.7
  container_name: rabbitmq
  environment:
    - RABBITMQ_DEFAULT_USER=user
    - RABBITMQ_DEFAULT_PASS=123456
  restart: always
  ports:
    - "9672:15672"
    - "8672:5672"
  logging:
    driver: "json-file"
    options:
      max-size: "200k"
      max-file: "10"

```
