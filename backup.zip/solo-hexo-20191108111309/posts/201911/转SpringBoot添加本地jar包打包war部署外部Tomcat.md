title: 【转】SpringBoot 添加本地 jar 包 打包 war 部署外部 Tomcat
date: '2019-11-06 09:47:09'
updated: '2019-11-06 09:48:18'
tags: [springboot]
permalink: /articles/2019/11/06/1573004829598.html
---
Java Web 开发用得比较少，刚开始接触 SpringBoot，在打包上有点坎坷，搜索了很久，部署起来总是有问题。下面分享一下成功部署的方法。

##### 第一步

在原来的 Application 类继承 SpringBootServletInitializer 并实现 configure 方法，完整代码如下：
```
@SpringBootApplicationpublic 
class SpringbootApplication extends SpringBootServletInitializer {    
	public static void main(String[] args) {
        	SpringApplication.run(SpringbootApplication.class, args);
    	}    
	@Override
    	protected SpringApplicationBuilder configure(SpringApplicationBuilder application){        
		return application.sources(SpringbootApplication.class);
    	}
}
```
##### 第二步

修改 pom.xml，因为要发布为 war，所以在 <project> 目录下添加
```
<packaging>war</packaging>
```

##### 第三步

打开 IDEA 的 Maven Projects 面板，双击 Lifecycle 下的 clean 和 package 命令，看到下图的 BUILD SUCCESS，表示打包成功，如果是 FAILE 则打包失败，查看失败的原因，进行修正。成功后在项目下的 target 目录下可以看到 war 文件。



因为在第二步中，并没有移除 SpringBoot 自带的 Tomcat，所以打包后的 war 不仅可以发布到外部 Tomcat，也能继续使用自带的 Tomcat 运行项目，运行方法，打开 cmd 命令行窗口，输入：

java -jar 路径/文件名.war

##### 如果你的项目还包含本地的 jar 文件，请往下看

maven 打包时，默认不会导入本地的 jar，会导致找不到 class，打包失败，所以打包的时候要把本地的 jar 也打包进去。

假设你的 jar 文件放在项目根目录下的 lib 文件夹，修改 pom.xml，用以下方法引用本地 jar，如我的 lib 目录下有一个 commons-beanutils-1.7.0.jar 文件。注意 <systemPath> 的路径，如果你的 jar 包是在其他路径，请自行修改， ${project.basedir} 是项目的根目录。
```
<dependency>
    <groupId>org.apache.commons</groupId>
    <artifactId>commons-beanutils-1.7.0</artifactId>
    <version>1.7.0</version>
    <scope>system</scope>
    <systemPath>${project.basedir}/lib/commons-beanutils-1.7.0.jar</systemPath></dependency>
```
同时还要添加一个插件，注意  <directory> 要指向你的 jar 所在路径
```
<plugin>
    <groupId>org.apache.maven.plugins</groupId>
    <artifactId>maven-war-plugin</artifactId>
    <configuration>
        <webResources>
            <resource>
                <directory>${project.basedir}/lib</directory>
                <targetPath>WEB-INF/lib</targetPath>
                <includes>
                    <include>**/*.jar</include>
                </includes>
            </resource>
        </webResources>
    </configuration></plugin>
```
  
  
作者：杜维希  
链接：https://www.jianshu.com/p/842f154b9cb2
