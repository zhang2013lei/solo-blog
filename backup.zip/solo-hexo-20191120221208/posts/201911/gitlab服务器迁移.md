title: gitlab服务器迁移
date: '2019-11-15 22:24:59'
updated: '2019-11-15 22:24:59'
tags: [gitlab]
permalink: /articles/2019/11/15/1573827899301.html
---
# 1、老服务器备份gitlab仓库
docker exec -it xxxxxxxx gitlab-rake gitlab:backup:create

# 2、老服务器拷贝备份文件到新服务器
scp /srv/gitlab/data/backups/1573613893_2019_11_13_10.8.3_gitlab_backup.tar root@新服务器ip:/srv/gitlab/data/backups/

# 3、新服务器恢复备份
docker exec -it xxxxxxx  gitlab-rake gitlab:backup:restore


# 4、升级gitlab版本
gitlab版本列表：https://hub.docker.com/r/gitlab/gitlab-ce/tags
升级Gitlab（注意：由于升级不能跨越大版本号，因此只能升级到当前大版本号到最高版本，方可升级到下一个大版本号）
依次执行下面指令逐步升级，在每一步安装成功后如果发现界面500，不可访问，那么执行
```
gitlab-ctl reconfigure
```
指令刷新配置文件。（一定保证数据可以正常访问方可执行下一步升级指令）

    gitlab-ce:10.8.6-ce.0
    gitlab-ce:11.0.4-ce.0
    gitlab-ce:11.11.8-ce.0
    gitlab-ce:12.1.6-ce.0
    gitlab-ce:12.4.2-ce.0
