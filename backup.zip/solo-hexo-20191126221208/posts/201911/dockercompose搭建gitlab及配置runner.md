title: docker-compose搭建gitlab及配置runner
date: '2019-11-15 22:15:46'
updated: '2019-11-15 22:20:35'
tags: [gitlab]
permalink: /articles/2019/11/15/1573827345905.html
---
# docker-compose.yml 配置

```
version: "3"
services:
 gitlab:
  image: 'gitlab/gitlab-ce:12.4.2-ce.0'
  restart: always
  hostname: 'gitlab.example.com'
  environment:
    GITLAB_OMNIBUS_CONFIG: |
      external_url 'http://服务器地址:8001'
      # Add any other gitlab.rb configuration here, each on its own line
  ports:
    - '8001:8001'
    - '8443:443'
  volumes:
    - '/srv/gitlab/config:/etc/gitlab'
    - '/srv/gitlab/logs:/var/log/gitlab'
    - '/srv/gitlab/data:/var/opt/gitlab'

 gitlab-runner:
   image: 'gitlab/gitlab-runner:latest'
   restart: always
   volumes:
     - /srv/gitlab-runner/config:/etc/gitlab-runner
     - /var/run/docker.sock:/var/run/docker.sock
```

# 注册runner

在启动了`gitlab-runner`容器后, 执行如下命令进入容器, 注册`runner`
```
docker exec -it gitlab-runner /bin/bash
root@492ce6ab72f9:/# gitlab-runner register
```
接下来需要填写的信息如下:
```
Please enter the gitlab-ci coordinator URL:
你的Gitlab地址: http(s)://gitlab.xxx.com

Please enter the gitlab-ci token for this runner:
你的Gitlab admin/runners页面中的token

Please enter the gitlab-ci description for this runner:
填写描述, 无关紧要

Please enter the gitlab-ci tags for this runner (comma separated):
填写标签, 没有标签谁都可以用, 有标签需要声明才可用, 例如java

Please enter the executor: docker-ssh, ssh, docker+machine, kubernetes, docker-ssh+machine, docker, parallels, shell, virtualbox:
选择你的executor: docker

Please enter the default Docker image (e.g. ruby:2.6):
选择一个默认镜像: 例如 docker:stable
```

# 修改runner配置

修改 /srv/gitlab-runner/config/config.toml 文件
```
concurrent = 1
check_interval = 0

[session_server]
  session_timeout = 1800

[[runners]]
  name = "runner"
  url = "gitlab地址"
  token = "注册自动生成的token"
  executor = "docker"
  [runners.custom_build_dir]
  [runners.docker]
    tls_verify = false
    image = "docker:stable"
    privileged = false
    disable_entrypoint_overwrite = false
    oom_kill_disable = false
    disable_cache = false
    #这一行添加如下配置
    volumes = ["/var/run/docker.sock:/var/run/docker.sock","/builds:/builds","/cache"]
    shm_size = 0
  [runners.cache]
    [runners.cache.s3]
    [runners.cache.gcs]
```

