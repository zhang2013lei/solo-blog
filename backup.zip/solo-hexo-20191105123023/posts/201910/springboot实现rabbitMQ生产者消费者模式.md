title: springboot 实现 rabbitMQ 生产者消费者模式
date: '2019-10-31 20:13:42'
updated: '2019-10-31 20:13:42'
tags: [mq]
permalink: /articles/2019/10/31/1572524022464.html
---
> 在业务逻辑的异步处理，系统解耦，分布式通信以及控制高并发的场景下，消息队列有着广泛的应用。

![请输入图片描述][1]
如上图，生产者消费者模型：添加了一个队列，并创建了两个消费者用于监听队列消息，我们发现，当有消息到达时，两个消费者会交替收到消息。这一过程虽然不用创建交换机，但会使用默认的交换机，并用默认的直连（default-direct）策略连接队列；

demo地址：[https://gitee.com/shenzhanwang/Spring-rabbitMQ][2]

pom地址
```
<!-- rabbitMQ -->
<dependency>
	<groupId>org.springframework.boot</groupId>
	<artifactId>spring-boot-starter-amqp</artifactId>
</dependency>
```
# 一、配置 #

```
import org.springframework.amqp.rabbit.config.SimpleRabbitListenerContainerFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * 连接rabbitMQ的基本配置
 */
@Configuration
public class RabbitConfig {
    @Bean
    public RabbitTemplate rabbitTemplate(ConnectionFactory connectionFactory) {
        RabbitTemplate template = new RabbitTemplate(connectionFactory);
        template.setMessageConverter(new Jackson2JsonMessageConverter());
        return template;
    }

    @Bean
    public SimpleRabbitListenerContainerFactory rabbitListenerContainerFactory(ConnectionFactory connectionFactory) {
        SimpleRabbitListenerContainerFactory factory = new SimpleRabbitListenerContainerFactory();
        factory.setConnectionFactory(connectionFactory);
        factory.setMessageConverter(new Jackson2JsonMessageConverter());
        return factory;
    }
}
```
# 二、消费者队列配置 #
```
import org.springframework.amqp.core.Queue;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * 消费者队列配置
 */
@Configuration
public class RabbitQueue {

    @Autowired
    RabbitConfig rabbitconfig;

    /**
     * 测试队列,后续仿造此方法复制即可
     * @return
     */
    @Bean
    public Queue myQueue() {
        Queue queue = new Queue("myqueue");
        return queue;
    }

}
```
# 三、生产者 #
新增接口 Producer 
```
public interface Producer {

    public void sendMessage(String queue,Object message);

}
```
新增实现类
```
@Service
public class ProducerImpl implements Producer{

    @Autowired
    RabbitTemplate rabbitTemplate;

    @Override
    public void sendMessage(String queue, Object message) {
        rabbitTemplate.setQueue(queue);
        rabbitTemplate.convertAndSend(queue,message);
    }
}
```

# 四、消费者 #
```
@Component
public class MyqueueListener {

    /**
     * 测试消费者
     * @param mail
     * @throws Exception
     */
    @RabbitListener(queues = "myqueue")
    public void displayMail(String mail) throws Exception {
        System.out.println("队列监听器1号收到消息"+mail);
    }

}
```
# 五、测试  #
```
@RunWith(SpringRunner.class)
@SpringBootTest
public class JwtTest {
    @Autowired
    private Producer producer ;

    @Test
    public void test() {
        producer.sendMessage("myqueue","hello world");
    }

}
```
  [1]: http://git.oschina.net/uploads/images/2017/0223/081751_c96aa8d6_1110335.png
  [2]: https://gitee.com/shenzhanwang/Spring-rabbitMQ
