title: java实体类转成map
date: '2019-10-31 20:11:12'
updated: '2019-10-31 20:11:12'
tags: [java]
permalink: /articles/2019/10/31/1572523872330.html
---
```
public Map<String,Object> toMap(Object o){
        Map<String,Object> map = new HashMap<String, Object>();
        Field[] fields = o.getClass().getDeclaredFields();
        for (Field field : fields) {
            Object obj;
            try {
                obj = field.get(this);
                if(obj!=null){
                    map.put(field.getName(), obj);
                }
            } catch (IllegalArgumentException e) {
                e.printStackTrace();
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
        }
        return map;
    }
```
