title: spring boot 实现MyBatis-Plus 乐观锁插件
date: '2019-10-31 20:13:10'
updated: '2019-10-31 20:13:10'
tags: [springboot]
permalink: /articles/2019/10/31/1572523990716.html
---
> MyBatis-Plus （简称 MP）是一个 MyBatis 的增强工具，在 MyBatis
> 的基础上只做增强不做改变，为简化开发、提高效率而生。
>  官方文档 [https://mp.baomidou.com/guide/][1]

# 主要适用场景 #
意图：

当要更新一条记录的时候，希望这条记录没有被别人更新

乐观锁实现方式：

 - 取出记录时，获取当前version
 - 更新时，带上这个version
 - 执行更新时， set version = newVersion where version = oldVersion
 - 如果version不对，就更新失败

# 一、配置 #
```
@Bean
public OptimisticLockerInterceptor optimisticLockerInterceptor() {
    return new OptimisticLockerInterceptor();
}

```
# 二、注解实体字段 @Version 必须要 #
```
@Version
private Integer version;
```
> 特别说明:
> 
>     支持的数据类型只有:int,Integer,long,Long,Date,Timestamp,LocalDateTime
>     整数类型下 newVersion = oldVersion + 1
>     newVersion 会回写到 entity 中
>     仅支持 updateById(id) 与 update(entity, wrapper) 方法
>     在 update(entity, wrapper) 方法下, wrapper 不能复用!!!

  [1]: https://mp.baomidou.com/guide/
