title: ' IDEA 初始配置教程 （转）'
date: '2019-10-31 20:08:44'
updated: '2019-10-31 20:08:44'
tags: [idea]
permalink: /articles/2019/10/31/1572523724565.html
---
转发自[http://blog.csdn.net/isea533/article/details/53706744][1]

###  IDEA 初始配置教程 ###

如果你是第一次使用 IDEA，或者对 IDEA 常用配置仍然不熟悉，那么本文就特别适合你。

本文只是根据我自己的使用经验来进行配置，不一定适合所有的情况，但是对你肯定会有帮助。

IDEA 官方地址https://www.jetbrains.com/idea/

官方提供免费的【社区版】，还有收费的【高级版】（可以免费试用 1 个月）。

下面的设置针对【高级版】进行设置，【社区版】由于功能不完整，所以设置也会有所不同，这里不做介绍。

**详情看**[http://blog.csdn.net/isea533/article/details/53706744][1]


  [1]: http://blog.csdn.net/isea533/article/details/53706744
