title: 基于Docker搭建MySQL主从复制
date: '2019-11-06 10:29:47'
updated: '2019-11-06 10:48:58'
tags: [mysql]
permalink: /articles/2019/11/06/1573007387549.html
---
本篇博文相对简单，因为是初次使用Docker，MySQL的主从复制之前也在Centos环境下搭建过，但是也忘的也差不多了，因此本次尝试在Docker中搭建。根据网上教程走还是踩了一些坑，不过所幸最终搭建成功，因此记录下来，避免以后踩了重复的坑。

## 搭建环境

Centos 7.2 64位

MySQL 5.7.13

Docker

docker-compose

接下来，我们将会在一台服务器上安装docker，并使用docker运行三个MySQL容器，分别为一主两从。

## 安装docker

[https://docs.docker.com/install/linux/docker-ce/centos/](https://docs.docker.com/install/linux/docker-ce/centos/)

## 安装docker-compose

https://docs.docker.com/compose/install/#install-compose



## 启动Docker

启动Docker

```
systemctl start docker
```

## docker-compose.yml配置
```
 db-master:
  image: mysql:5.6
  restart: always
  environment:
      - MYSQL_ROOT_PASSWORD=123456
      - TZ=Asia/Shanghai
  ports:
    - 3308:3306 
  volumes:
    - /opt/mysql-master/config:/etc/mysql/conf.d
    - /opt/mysql-master/data:/var/lib/mysql

 db-slave:
  image: mysql:5.6
  restart: always
  environment:
    - MYSQL_ROOT_PASSWORD=123456
    - TZ=Asia/Shanghai
  ports:
    - 3309:3306
  volumes:
    - /opt/mysql-slave1/config:/etc/mysql/conf.d
    - /opt/mysql-slave1/data:/var/lib/mysql
```

使用Navicat连接测试

![null](https://static.oschina.net/uploads/space/2018/0510/114916_0h3I_3773384.png)

MySQL主容器已经启动成功

## 创建主容器的复制账号

![null](https://static.oschina.net/uploads/space/2018/0510/120249_0ZQx_3773384.png)

使用Navicat友好的图像化界面执行SQL

```
GRANT REPLICATION SLAVE ON *.* to 'backup'@'%' identified by 'backup';
show grants for 'backup'@'%';
```

出现如下信息表示授权成功

![null](https://static.oschina.net/uploads/space/2018/0510/121018_Vtxn_3773384.png)

## 修改主容器MySQL配置环境

在/opt/mysql-master/config 创建my-custom.cnf

```
[mysqld]
lower_case_table_names = 1
character-set-client-handshake = FALSE
character-set-server = utf8mb4
collation-server = utf8mb4_unicode_ci
init_connect='SET NAMES utf8mb4'

default-time_zone = '+8:00'

sql_mode='STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION'

log-bin=mysql-bin
server-id=1
binlog-do-db=xxx库

[client]
default-character-set = utf8mb4

[mysql]
default-character-set = utf8mb4
```


解释：

log-bin=mysql-bin 使用binary logging，mysql-bin是log文件名的前缀

server-id=1 唯一服务器ID，非0整数，不能和其他服务器的server-id重复

binlog-do-db 二进制日志记录的数据库(多数据库用逗号，隔开)

binlog-ignore-db 二进制日志中忽略数据库 (多数据库用逗号，隔开)


重启 mysql 的docker , 让配置生效

```
[root@VM_0_17_centos master]# docker restart master
```

启动后，重新测试连接，连接成功表示主容器配置成功

## MySQL从容器配置


在/opt/mysql-slave1/config 创建my-custom.cnf

```
[mysqld]
lower_case_table_names = 1
character-set-client-handshake = FALSE
character-set-server = utf8mb4
collation-server = utf8mb4_unicode_ci
init_connect='SET NAMES utf8mb4'

default-time_zone = '+8:00'

sql_mode='STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION'

log-bin=mysql-bin
server-id=2
replicate-do-db=xxx库

[client]
default-character-set = utf8mb4

[mysql]
default-character-set = utf8mb4
```
解释：

replicate-do-db 设定需要复制的数据库(多数据库使用逗号，隔开)

replicate-ignore-db 设定需要忽略的复制数据库 (多数据库使用逗号，隔开) 

replicate-do-table 设定需要复制的表 

replicate-ignore-table 设定需要忽略的复制表 

replicate-wild-do-table 同replication-do-table功能一样，但是可以通配符 

replicate-wild-ignore-table 同replication-ignore-table功能一样，但是可以加通配符 

  

与上述对比，这里的replicate就很好理解了，下面简单说几点。 

例如： 从库忽略复制数据库test3，但是需要说明的是，其实从库的relaylog中是从在关于test3的相关日志，只是从库没有使用罢了。

增加通配符的两个配置

replicate-wild-do-table=db_name.% 只复制哪个库的哪个表 

replicate-wild-ignore-table=mysql.% 忽略哪个库的哪个表


## 配置主从复制

使用Navicat连接slave1后新建查询，执行以下SQL

```
CHANGE MASTER TO 
MASTER_HOST='ip',
MASTER_PORT=3306,
MASTER_USER='backup',
MASTER_PASSWORD='backup';

START SLAVE;
```

MASTER_HOST 填Navicat连接配置中的ip应该就可以

MASTER_PORT 主容器的端口

MASTER_USER 同步账号的用户名

MASTER_PASSWORD 同步账号的密码

## 检查是否配置成功

```
show slave status;
```

![null](https://static.oschina.net/uploads/space/2018/0510/123902_gnvI_3773384.png)

Slave_IO_State 如果是Waiting for master to send event，那么就成功一半了，如果是Connecting to master，基本就是配置失败了，建议重新检查下配置，具体失败的原因可以查看日志追踪

```
[root@VM_0_17_centos master]# docker logs slave -f
```

我遇到的是MASTER_USER和MASTER_PASSWORD是否手打输错了，贴出错误日志

```
2018-05-10T02:57:00.688887Z 11 [ERROR] Slave I/O for channel '': error connecting to master 'bakcup@ip:3306' - retry-time: 60  retries: 2, Error_code: 1045
2018-05-10T02:58:00.690476Z 11 [ERROR] Slave I/O for channel '': error connecting to master 'bakcup@ip:3306' - retry-time: 60  retries: 3, Error_code: 1045
```

注意看日志中的bakcup，解决方法如下

```
STOP SLAVE;

CHANGE MASTER TO 
MASTER_HOST='连接Navicat的ip',
MASTER_PORT=正确的端口,
MASTER_USER='正确的用户名',
MASTER_PASSWORD='正确的密码';

START SLAVE;
```

接着上文，我们说成功一半，并没有说成功了，那么另一半在于Slave_IO_Running与Slave_SQL_Running

如果都是Yes，那么恭喜你，可以测试主从复制的效果了，如果有一个不是Yes，一半是重启从容器后，事务回滚引起的，那么给出解决方法如下

```
stop slave ;
set GLOBAL SQL_SLAVE_SKIP_COUNTER=1;
start slave ;
```

执行后，再次观察三个关键字段应该就都没问题了

至此，一主一从已经搭建完成，再添加从实例的方式与上文一致，这里就不在赘述了。

## 测试主从复制

首先，在主实例中创建一个测试数据库

![null](https://static.oschina.net/uploads/space/2018/0510/130207_7Ty1_3773384.png)

打开（刷新）从实例，可见test库已存在

![null](https://static.oschina.net/uploads/space/2018/0510/130133_ITNO_3773384.png)

在test库中创建一个表t_test，添加一个id测试字段

向表中添加几个数据

![null](https://static.oschina.net/uploads/space/2018/0510/130357_IEZg_3773384.png)

刷新从库，可见t_test表及其中1、2、3、4数据已存在

至此，一个具备主从复制的一主两从的MySQL就已搭建完成。

## [MySQL复制异常】 Cannot execute statement: impossible to write to binary log since

 MySQL复制错误]Last_Errno: 1666 Last_Error: Error executing row event: 'Cannot execute statement: imposs

Cannot execute statement: impossible to write to binary log since BINLOG_FORMAT = STATEMENT and at least one table uses a storage engine limited to row-based logging. InnoDB is limited to row-logging when transaction isolation level is READ COMMITTED or READ UNCOMMITTED

  

貌似是statement模式不足以应付应用，换成mixed试试看吧：

在从库执行:

mysql> stop slave;

Query OK, 0 rows affected (0.00 sec)

  

mysql> start slave;

Query OK, 0 rows affected (0.01 sec)

  

  

登录主库:

mysql> SET GLOBAL binlog_format=MIXED;

Query OK, 0 rows affected (0.00 sec)

  

  

  

ps：之前从库设置，没有效果，在主库做设置就生效了.

注意：命令行执行的话，重启后会无效，为了永久生效的话把配置加到配置.

[root@mysql-rtb-master ~]# cat /etc/my.cnf

  

[mysqld]

binlog_format=mixed
