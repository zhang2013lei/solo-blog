title: 【转】SpringBoot:集成Shiro之Shiro标签(.jsp和.ftl)
date: '2019-11-06 09:33:46'
updated: '2019-11-06 09:34:45'
tags: [springboot]
permalink: /articles/2019/11/06/1573004026156.html
---
![null](//upload-images.jianshu.io/upload_images/1396375-b8aa328167a528d2.jpg?imageMogr2/auto-orient/strip|imageView2/2/w/529)

  

#### 前言

---

上一篇博客,我们说到如何在用户请求的时候,拦截用户请求进行操作,这一篇博客我们来聊一下如何使用Shiro标签在网页之中进行用户角色和权限控制.那么,我们就看一下具体的场景,假设页面当中有一个新增用户按钮,我们需要当拥有admin角色的用户登录认证完成之后显示,普通用户不显示,那么这时候我们就需要使用Shiro标签来做处理了.例如这个例子,我们就可以用一下代码来实现.如果含有admin就会显示,反之,则不会显示.

```xml
<shiro:hashRole name = "admin">
    <button >新增用户</button>
</shiro:hashRole>

```
#### JSP的Shiro标签

---

在JSP中使用Shiro标签比较简单,我们只需要注意用法即可.下面我就把所以Shiro标签放在下面了,各位看官自行查考.
```
<shiro:guest>
    游客访问 <a href = "login.jsp"></a>
</shiro:guest>
 
user 标签：用户已经通过认证\记住我 登录后显示响应的内容
<shiro:user>
    欢迎[<shiro:principal/>]登录 <a href = "logout">退出</a>
</shiro:user>
 
authenticated标签：用户身份验证通过，即 Subjec.login 登录成功 不是记住我登录的
<shiro:authenticted>
    用户[<shiro:principal/>] 已身份验证通过
</shiro:authenticted>
 
notAuthenticated标签：用户未进行身份验证，即没有调用Subject.login进行登录,包括"记住我"也属于未进行身份验证
<shiro:notAuthenticated>
    未身份验证(包括"记住我")
</shiro:notAuthenticated>
 
 
principal 标签：显示用户身份信息，默认调用
Subjec.getPrincipal()获取，即Primary Principal
<shiro:principal property = "username"/>
 
hasRole标签：如果当前Subject有角色将显示body体内的内容
<shiro:hashRole name = "admin">
    用户[<shiro:principal/>]拥有角色admin
</shiro:hashRole>
 
hasAnyRoles标签：如果Subject有任意一个角色(或的关系)将显示body体里的内容
<shiro:hasAnyRoles name = "admin,user">
    用户[<shiro:pricipal/>]拥有角色admin 或者 user
</shiro:hasAnyRoles>
 
lacksRole:如果当前 Subjec没有角色将显示body体内的内容
<shiro:lacksRole name = "admin">
    用户[<shiro:pricipal/>]没有角色admin
</shiro:lacksRole>
 
hashPermission:如果当前Subject有权限将显示body体内容
<shiro:hashPermission name = "user:create">
    用户[<shiro:pricipal/>] 拥有权限user:create
</shiro:hashPermission>
 
lacksPermission:如果当前Subject没有权限将显示body体内容
<shiro:lacksPermission name = "org:create">
    用户[<shiro:pricipal/>] 没有权限org:create
</shiro:lacksPermission>

```

#### Freemark的Shiro标签

---

在SpringBoot里面并不是直接支持JSP文件的,然后我就在项目中使用了Freemark,但是Shiro标签并不能直接支持.ftl文件,所以我们需要先引入一个Maven依赖.

  


```

<dependency>
    <groupId>net.mingsoft</groupId>
    <artifactId>shiro-freemarker-tags</artifactId>
    <version>0.1</version>
</dependency>

```

然后,我们写一个名为ShiroTagsFreeMarkerCfg配置类来对Freemark使用Shiro标签进行配置.当然了,要确定配置类能被正确注入到Bean中,代码如下所示.

```
import com.jagregory.shiro.freemarker.ShiroTags;
import freemarker.template.TemplateModelException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.view.freemarker.FreeMarkerConfigurer;

import javax.annotation.PostConstruct;

@Component
public class ShiroTagsFreeMarkerCfg {

    @Autowired
    private FreeMarkerConfigurer freeMarkerConfigurer;

    @PostConstruct
    public void setSharedVariable() throws TemplateModelException {
        freeMarkerConfigurer.getConfiguration().setSharedVariable("shiro", new ShiroTags());
    }
}


```
配置类搞好之后,我们就可以在.ftl文件中使用Shiro的权限标签了,标签格式如下所示.
```
<@shiro.guest>  
游客访问 <a href = "login.jsp"></a>
</@shiro.guest> 

user 标签：用户已经通过认证\记住我 登录后显示响应的内容
<@shiro.user>  
欢迎[<@shiro.principal/>]登录，<a href="/logout.html">退出</a>  
</@shiro.user>   

 authenticated标签：用户身份验证通过，即 Subjec.login 登录成功 不是记住我登录的
<@shiro.authenticated>  
    用户[<@shiro.principal/>]已身份验证通过  
</@shiro.authenticated>   
 
notAuthenticated标签：用户未进行身份验证，即没有调用Subject.login进行登录,包括"记住我"也属于未进行身份验证
<@shiro.notAuthenticated>
    当前身份未认证（包括记住我登录的）
</@shiro.notAuthenticated> 
 
 
principal 标签：显示用户身份信息，默认调用
Subjec.getPrincipal()获取，即Primary Principal
<@shiro.principal property="username"/>

 
hasRole标签：如果当前Subject有角色将显示body体内的内容
<@shiro.hasRole name="admin">  
    用户[<@shiro.principal/>]拥有角色admin<br/>  
</@shiro.hasRole> 
 
hasAnyRoles标签：如果Subject有任意一个角色(或的关系)将显示body体里的内容
<@shiro.hasAnyRoles name="admin,user,member">  
用户[<@shiro.principal/>]拥有角色admin或user或member<br/>  
</@shiro.hasAnyRoles>   
 
lacksRole:如果当前 Subjec没有角色将显示body体内的内容
<@shiro.lacksRole name="admin">  
用户[<@shiro.principal/>]不拥有admin角色
</@shiro.lacksRole>   
 
hashPermission:如果当前Subject有权限将显示body体内容
<@shiro.hasPermission name="user:add">  
    用户[<@shiro.principal/>]拥有user:add权限
</@shiro.hasPermission>   

lacksPermission:如果当前Subject没有权限将显示body体内容
<@shiro.lacksPermission name="user:add">  
    用户[<@shiro.principal/>]不拥有user:add权限
</@shiro.lacksPermission> 

```
[参考博客](https://www.sojson.com/blog/143.html)
##### [Demo传送门](https://gitee.com/676758285/shiro_blog_demo)

  
  
作者：神经骚栋  
链接：https://www.jianshu.com/p/ac9cfddd169d  
来源：简书  
著作权归作者所有。商业转载请联系作者获得授权，非商业转载请注明出处。
